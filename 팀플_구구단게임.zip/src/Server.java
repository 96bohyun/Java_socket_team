import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Vector;

public class Server {

   public static void main(String[] args) throws Exception {
      ServerSocket ss = new ServerSocket(9001);
      System.out.println("���� ����");

      try {
         while (true) {
            Game game = new Game();

            Player player1 = new Player(game, ss.accept());
            Player player2 = new Player(game, ss.accept());

            player1.setOther(player2);
            player2.setOther(player1);

            player1.start();
            player2.start();
            System.out.println("��� ����");
         }
      } finally {
         ss.close();
      }
   }
}

class Game {
   int result = 3;
   int correct = 2;
   Vector<String> V99 = new Vector<String>(2); // ������ ����
   Vector<Integer> tmp = new Vector<Integer>(); // ���������� ����
   boolean t;

   public void setStore(int i) {
      try {
         tmp.add(i); // vector�� ������� ���� i�� �ֱ�
      } catch (Exception e) {
         e.printStackTrace();
      }
   }

   public void setCompare() {
      try {
         if (tmp.get(0) == tmp.get(1)) {
            System.out.println("���");
            tmp.clear();
            result = 0;
         } else if (((tmp.get(0) == 0) && (tmp.get(1) == 1) || (tmp.get(0) == 1) && (tmp.get(1) == 2)
               || (tmp.get(0) == 2) && (tmp.get(1) == 0))) {
            System.out.println("���� �� ����� �̱�");
            result = 1;
         } else {
            System.out.println("���� �� ����� ��");
            result = 2;
         }
      } catch (Exception e) {
      }
   }

   public void setGame99(String s) {
      try {
         V99.add(s);
      } catch (Exception e) {
      }
   }

   public void setCompare99() {
      try {
         if (V99.get(0).equals(V99.get(1))) {
            System.out.println("����");
            correct = 1;
         } else {
            System.out.println("��");
            correct = 0;
         }
      } catch (Exception e) {
      }
   }
}

class Player extends Thread {
   Game game;
   Socket socket;
   BufferedReader input;
   PrintWriter output;
   Player other;
   String r, position;

   public Player(Game game, Socket socket) {
      this.game = game;
      this.socket = socket;

      try {
         input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
         output = new PrintWriter(socket.getOutputStream(), true);
         output.println("START ");
      } catch (IOException e) {
         System.out.println("������ ���������ϴ�. " + e);
      }
   }

   public void setOther(Player other) {
      this.other = other;
   }

   public void run() {
      try {
         output.println("PRINT ����Ǿ����ϴ�. ");

         while (true) {
            String command = input.readLine();
            if (command == null)
               continue;
            if (command.startsWith("RSP")) {
               output.println("stop");
               int i = Integer.parseInt(command.substring(4, 5)); // Client������
                                                      // ii
               game.setStore(i);
               game.setCompare();
               if (game.result == 0) {
                  output.println("tie");
                  other.output.println("tie");
                  game.result = 3;
               } else if (game.result == 1) {
                  output.println("def");
                  other.output.println("off");
               } else if (game.result == 2) {
                  output.println("off");
                  other.output.println("def");
               }
            }
            if (command.startsWith("MOVE")) {
               if (command.length() == 8) {
                  if (command.substring(6, 7).equals("*")) {
                     int i = Integer.parseInt(command.substring(5, 6));
                     int j = Integer.parseInt(command.substring(7));
                     r = Integer.toString(i * j);
                     output.println("OK");
                     other.output.println("QUIZ");
                  }
               } else
                  r = command.substring(5);
               other.output.println("PRINT " + command.substring(5));
               game.setGame99(r);
               game.setCompare99();
               if (game.V99.size() == 2)
                  game.V99.clear();

               if (game.correct == 1) {
                  other.output.println("defense");
                  output.println("offense");
               } else if (game.correct == 0) {
                  other.output.println("WIN");
                  output.println("LOSE");
               }
            } else if (command.startsWith("end"))
                     other.output.println("WIN");
         }
      } catch (IOException e) {
         System.out.println("������ ������" + e);
      } finally {
         try {
            socket.close();
         } catch (IOException e) {
         }
      }
   }
}