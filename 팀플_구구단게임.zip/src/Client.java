import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class Client extends Thread implements ActionListener {
   private JButton[] buttons = new JButton[12];
   private JButton[] RSPb = new JButton[3];
   private JFrame frame, RSPf, Wf, Lf;
   private JButton wf, lf;
   private JPanel panel, panel2, panel3, RSPp;
   private JTextField txtF = new JTextField(45);
   private JTextArea txtA = new JTextArea(3, 50);
   private Socket socket;
   private BufferedReader input;
   private PrintWriter output;
   private String[] labels = { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "*", "C" };
   private JButton btn = new JButton("����");
   private int isOffense = 2, count = 0, oper = 0;
   private Timer timer;
   private TimerTask d_task;

   public Client() throws UnknownHostException, IOException {
      socket = new Socket("localhost", 9001);

      input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
      output = new PrintWriter(socket.getOutputStream(), true);

      txtA.setEditable(false);
      txtF.setEditable(false);
      Wf = new JFrame("GAME OVER");
      Lf = new JFrame("GAME OVER");
      Wf.setSize(600, 450);
      Lf.setSize(600, 450);
      wf = new JButton(new ImageIcon("rsp/Win.jpg"));
      lf = new JButton(new ImageIcon("rsp/Lose.jpg"));
      Wf.add(wf);
      Lf.add(lf);
      Wf.setVisible(false);
      Lf.setVisible(false);
      // ������
      frame = new JFrame();
      panel = new JPanel();
      panel2 = new JPanel();
      panel3 = new JPanel();
      panel3.setLayout(new GridLayout(0, 3, 3, 3));
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      frame.add(panel, BorderLayout.CENTER);
      frame.add(txtA, BorderLayout.SOUTH);
      frame.setSize(600, 250);
      frame.setVisible(false);
      panel.add(txtA);
      panel2.add(txtF);
      panel2.add(btn);
      

      for (int i = 0; i < 12; i++) {
         buttons[i] = new JButton(labels[i]);
         if (i > 9) {
            buttons[i].setForeground(Color.red);
         }
         buttons[i].addActionListener(this);
         panel3.add(buttons[i]);
      }
      panel3.repaint();
      btn.addActionListener(this);

      frame.add(panel, BorderLayout.NORTH);
      frame.add(panel2, BorderLayout.CENTER);
      frame.add(panel3, BorderLayout.SOUTH);

      // ����������
      RSPf = new JFrame("���� ���ϱ�");
      RSPp = new JPanel();
      RSPp.setLayout(new GridLayout(0, 3, 2, 2));
      RSPf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      RSPf.add(RSPp, BorderLayout.CENTER);
      RSPf.setSize(300, 200);
      RSPf.setVisible(true);

      RSPb[0] = new JButton(new ImageIcon("rsp/R.png"));
      RSPb[1] = new JButton(new ImageIcon("rsp/S.png"));
      RSPb[2] = new JButton(new ImageIcon("rsp/P.png"));
      for (int i = 0; i < 3; i++) {
         final int ii = i;
         RSPb[i].setBackground(Color.WHITE);
         RSPb[i].addActionListener(e -> {
            RSPb[ii].setText("");
            output.println("RSP " + ii);
         });
         RSPp.add(RSPb[i]);
      }
      RSPf.setResizable(false);
      frame.setResizable(false);
   }

   public void run() {
      String response;
      try {
         response = input.readLine();

         if (response.startsWith("START"))
            frame.setTitle("����������");

         while (true) {
            response = input.readLine();
            // ����������
            if (response.startsWith("stop")) {
               RSPb[0].setEnabled(false);
               RSPb[1].setEnabled(false);
               RSPb[2].setEnabled(false);
            } else if (response.startsWith("tie")) {
               RSPf.setTitle("���º��Դϴ�.");
               for (int i = 0; i < 3; i++)
                  RSPb[i].setEnabled(true);
            } else if (response.startsWith("off")) {
               RSPf.setVisible(false);
               frame.setVisible(true);
               frame.setTitle("����");
               isOffense = 1;
            } else if (response.startsWith("def")) {
               RSPf.setVisible(false);
               frame.setVisible(true);
               frame.setTitle("����");
               isOffense = 0;
            }
            // ������
            if (response.startsWith("PRINT"))
               txtA.setText(response.substring(6));
            else if (response.startsWith("offense")) {
               frame.setTitle("����");
               isOffense = 1;
            } else if (response.startsWith("defense")) {
               frame.setTitle("����");
               isOffense = 0;
            } else if (response.startsWith("LOSE")) {
               frame.setVisible(false);
               Lf.setVisible(true);
            } else if (response.startsWith("WIN")) {
               frame.setVisible(false);
               Wf.setVisible(true);
            } else if (response.startsWith("OK")) {
               btn.setEnabled(false);
            } else if (response.startsWith("QUIZ")) {
               btn.setEnabled(true);
               makeTimer();
               timer.schedule(d_task, 2000); // 2�� �ڿ� d_task ����
            }
            try {
               Thread.sleep(200);
            } catch (InterruptedException e) {
               e.printStackTrace();
            }
         }
      } catch (IOException e) {
         e.printStackTrace();
      } finally {
         try {
            socket.close();
         } catch (IOException e) {
            e.printStackTrace();
         }
      }
   }

   public void makeTimer() {
      timer = new Timer();
      d_task = new TimerTask() {
         public void run() {
            frame.setVisible(false);
            Lf.setVisible(true);
            output.println("end");
         }
      };
   }

   public static void main(String[] args) throws UnknownHostException, IOException {
      Client client = new Client();
      client.start();
   }

   @Override
   public void actionPerformed(ActionEvent e) {
      String command = e.getActionCommand();
      if (e.getSource() == btn) {
         // �޼��� �Է¾��� ������ ���� ���
         if (txtF.getText().equals("")) {
            count = 0;
            oper = 0;
            return;
         } else {
             if(isOffense==0)
                     timer.cancel();
            // textfield�� �Էµ� ���� �Ǵ� ���� ���۹�ư�� ���� ����
            txtA.setText("");
            output.println("MOVE " + txtF.getText());
            txtF.setText("");
            count = 0;
            oper = 0;
         }
      } else {
         // ���ڹ�ư ������ ��
         // textfield�� ���� ��ư�� �ش��ϴ� ���� Ȥ�� ��ȣ�� ���

         if (e.getSource() == this.buttons[10]) {
            if (isOffense == 0)
               txtF.setText("����� �����Դϴ�. ������ ���� �� ������ C�� ���� �ʱ�ȭ ���ּ���.");
            else {
               if (oper == 0 && count > 0) {
                  txtF.setText(txtF.getText() + command);
                  txtA.setText("");
                  count = 0;
                  oper++;
               }
            }
         }
         for (int i = 0; i < 10; i++) {
            if (e.getSource() == this.buttons[i]) {
               if (isOffense == 1) {
                  if (i == 0) {
                     txtA.setText("1���� 9������ ���� �Է��ؾ��մϴ�.");
                     count = 0;
                  } else if (count == 0) {
                     txtF.setText(txtF.getText() + command);
                     count++;
                  } else
                     txtA.setText("1���� 9������ ���� �Է��ؾ��մϴ�.");
               } else
                  txtF.setText(txtF.getText() + command);
            }
         }
         // 'C' ������ ����â�� ���� ���� �ʱ�ȭ��
         if (e.getSource() == this.buttons[11]) {
            txtF.setText("");
         }
      }
   }
}